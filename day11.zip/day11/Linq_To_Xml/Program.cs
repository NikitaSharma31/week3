﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Linq_To_Xml
{
    class Program
    {
        string path = @"C:\Users\nikita.sharma\source\repos\day11\Linq_To_Xml\Data.xml";

        private void GETXMLData()

        {
            //Step 1:Connection String 
            Console.WriteLine(" getting data");
            try

            {
                XDocument doc = XDocument.Load(path);

                // XDocument  doc  = XDocument.Parse(path); 

                var students = from participant in doc.Descendants("Participant")

                               select new

                               {

                                   ID = Convert.ToInt32(participant.Attribute("ID").Value),

                                   Name = participant.Element("Name").Value

                               };

                //  Console.WriteLine("Executing For each now ..!!" + students.Count());

                foreach (var student in students)

                {

                    Console.WriteLine(student.ID + "-" + student.Name);

                    // Console.WriteLine("Running Foreach");

                }


            }

            catch (Exception ex)

            {

                Console.WriteLine(ex.Message);



            }

        }

        private void InsertXMLData(string name)

        {
            Console.WriteLine(" inserting data");

            try

            {

                XDocument myXML = XDocument.Load(path);

                XElement newParticipant = new XElement("Participant", new XElement("Name", name));

                var LastStudent = myXML.Descendants("Participant").Last();//Gets the last element  

                int newID = Convert.ToInt32(LastStudent.Attribute("ID").Value); //It gets the ID of last element  



                newParticipant.SetAttributeValue("ID", newID + 1);//Setting Attribute 



                myXML.Element("Participants").Add(newParticipant);//Adding New Element 

                myXML.Save(path); // Saving changes 

            }

            catch (Exception)

            {





            }

        }

        private void ModifyXMLData(string name, string newID, string id)

        {
            Console.WriteLine("modifing data");
           
                try
                {
                    XDocument doc = XDocument.Load(path);
                    XElement element = doc.Descendants("Participant").Where(c => c.Attribute("ID").Value.Equals(id)).FirstOrDefault();
                    element.SetAttributeValue("ID", newID);
                    element.SetElementValue("Name", name);
                    doc.Save(path);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + "\n" + e.StackTrace);
                }
            



        }


        private void DeleteXMLData(string id)
        {
            Console.WriteLine("deleting data");
            try
            {
                XDocument doc = XDocument.Load(path);
                XElement element = doc.Descendants("Participant").Where(c => c.Attribute("ID").Value.Equals(id)).FirstOrDefault();
                element.Remove();
                doc.Save(path);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message + "\n" + e.StackTrace);
            }
        }




        static void Main(string[] args)

        {

             Console.WriteLine("Implementing LINQ to XML");



            Program obj1 = new Program();

            obj1.GETXMLData();



            obj1.InsertXMLData("hello");

            obj1.GETXMLData();


            obj1.DeleteXMLData("5");
            obj1.GETXMLData();


            obj1.ModifyXMLData("pagal", "5", "2");
            obj1.GETXMLData();



        }



    }

}


