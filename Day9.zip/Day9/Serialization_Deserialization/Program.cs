﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Serialization_Deserialization
{
    class Program
    {
        static void Main(string[] args)
        {
            Tutorial obj = new Tutorial();
            obj.ID = 1000000;
            obj.Name = " NikitaSS";
            IFormatter formatter = new BinaryFormatter();

            Stream stream = new FileStream("C:\\Users\\nikita.sharma\\source\\repos\\Serialization_Deserialization\\demo1.txt" ,FileMode.Create, FileAccess.Write );
           formatter.Serialize(stream, obj);
           
            Console.WriteLine("objec is serialized");
            stream.Close();

           
            Stream stream1 = new FileStream("C:\\Users\\nikita.sharma\\source\\repos\\Serialization_Deserialization\\demo1.txt", FileMode.Open, FileAccess.Read);

            Tutorial obj1 = (Tutorial)formatter.Deserialize(stream1);
            Console.WriteLine("After deserialization");
            Console.WriteLine(obj1.ID);
            Console.WriteLine(obj1.Name);
            // stream.Close();

        }
    }
}
