﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Threading
{
    public class MyThread
    {
        public static void Display1Thread()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("thread first" + i);
            }
        }
        public static void Display2Thread()
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("thread second" + i);
            }
        }



        public static void print()
        {
            for (int i = 11; i < 20; i++)
            {
                Console.WriteLine($" thread in print {i}");
                Thread.Sleep(1000);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("multi threading ");

            // MyThread obj = new MyThread();
            // Thread Thread1 = new Thread( new ThreadStart(  obj.DisplayThread));
            //Thread1.Start();

            Thread a = new Thread(MyThread.Display1Thread);
            Thread b = new Thread(MyThread.Display2Thread);

            Console.WriteLine(" state status of a = {0}", a.IsAlive);
            Console.WriteLine(" state status of b = {0}", b.IsAlive);

            a.Start();
            b.Start();
            Console.WriteLine(" state status of a = {0}", a.IsAlive);
            Console.WriteLine(" state status of b = {0}", b.IsAlive);


            // a.Abort();
            // Console.WriteLine(" state status of a = {0}", a.IsAlive);
            //  Console.WriteLine(" state status of b = {0}", b.IsAlive);



            //Console.WriteLine(" after completion threading ");


            Thread workerThread = new Thread(MyThread.print);

            workerThread.Start();

            workerThread.Suspend();
             workerThread.Resume();
            // Thread thread2 = Thread.CurrentThread;
            // Console.WriteLine(" current state status= {0} " , thread2.IsAlive);

            //for (int i=0; i<10; i++)
            //{
            //    Console.WriteLine($"thread in main {i}");
            //    Thread.Sleep(200);
            //}
            Console.ReadKey();

        }
    }
}
