﻿using System;
using System.Collections.Generic;
using System.Linq;// provide classes interfaces that support linq queries
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[] { 1,2,3,4,5}; // integer array

            var result = from a in num where a < 4 orderby a select a; // linq 
            foreach(var items in result)
            {
                Console.WriteLine(items);
            }

        }
    }
}
